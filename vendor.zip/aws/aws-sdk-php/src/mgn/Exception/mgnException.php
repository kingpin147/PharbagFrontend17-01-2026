<?php
namespace Aws\mgn\Exception;

use Aws\Exception\AwsException;

/**
 * Represents an error interacting with the **Application Migration Service** service.
 */
class mgnException extends AwsException {}
